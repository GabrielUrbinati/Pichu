/*function mudarCor(cor){
    const botao = document.getElementById("botaoFixo");
    botao.style.backgroundColor = botao.style.backgroundColor === ""
}*/


document.addEventListener("DOMContentLoaded",function(){
    const botao = document.getElementById("botaoFixo");


    function mudarEstilo(corFundo,corTexto){ /* tipo uma interface pros dois eventos de baixo*/
        botao.style.backgroundColor = corFundo;;
        botao.style.color=corTexto
    
    }
    
    botao.onmouseover = function(){
        mudarEstilo("rgba(0, 0, 0, 0.9)","bisque");
    };
    
    
    botao.onmouseout = function(){
        mudarEstilo("rgba(0, 0, 0, 0.1)","rgba(0,0,0,0.7)");

    };


});

function scrollForm(){
    const form = document.getElementById("contato");

    form.scrollIntoView({behavior:"smooth"});

}