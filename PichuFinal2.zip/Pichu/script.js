/*function mudarCor(cor){
    const botao = document.getElementById("botaoFixo");
    botao.style.backgroundColor = botao.style.backgroundColor === "" /* tipo uma interface pros dois eventos de baixo*/



const botao = document.getElementById("botaoFixo");

function mudarEstilo(corFundo, corTexto) {
    botao.style.backgroundColor = corFundo;
    botao.style.color = corTexto;
}
    
botao.onmouseover = function() {
    mudarEstilo("rgba(0, 0, 0, 0.9)", "bisque");
};
    
botao.onmouseout = function() {
    mudarEstilo("rgba(0, 0, 0, 0.1)", "rgba(0,0,0,0.7)");
};
    
    // menu sanduíche
const menuToggle = document.getElementById("menuToggle");
const menu = document.querySelector("nav ul.menu");
    
menuToggle.addEventListener("click", function() {
    menu.classList.toggle("ativo");
});
    
    // rolagem suave até o formulário
function scrollForm() {
    const form = document.getElementById("contato");
    form.scrollIntoView({ behavior: "smooth" });
}

const botaoEnviar = document.getElementById("submit"); // quando clicar nele vai ativar a funcao 
const divMensagem = document.getElementById("mensagem");

botaoEnviar.addEventListener("click", function(event) {// essa funcao
    event.preventDefault(); // impede o reload da página

    const mensagem = "Cheque sua caixa de entrada!";
    divMensagem.textContent = mensagem;
    divMensagem.style.display = "block";

    setTimeout(() => {
        divMensagem.style.display="none";
    },2000)
});